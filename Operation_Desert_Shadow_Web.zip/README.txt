Operation Desert Shadow - Web version
=====================================
هذا ملف HTML جاهز للرفع على GitHub Pages.
خطوات سريعة لرفع الملف إلى مستودع GitHub:
1. أنشئ مستودعًا عامًا (public) باسم operation-desert-shadow أو أي اسم تريده.
2. ارفع ملف index.html إلى جذر المستودع (اضغط Add file -> Upload files أو Create new file ثم ألصق).
3. اذهب إلى Settings -> Pages، اختر Branch: main (أو master) وFolder: / (root)، واضغط Save.
4. بعد دقيقة أو دقيقتين افتح الرابط: https://<username>.github.io/<repo-name>/
